package com.pedscont.app

import android.app.*
import android.os.*
import android.content.*
import android.media.midi.*
import android.net.Uri
import android.webkit.*
import android.util.Base64
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
 private lateinit var web: WebView
 private val executor = Executors.newSingleThreadExecutor()
 private var pendingSlot: String? = null
 private val pickAudio = 100
 private var midiManager: MidiManager? = null
 private val openDevices = mutableMapOf<Int, MidiDevice>()
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  window.decorView.systemUiVisibility = (4 or 1024 or 4096)
  web = WebView(this); web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true; web.settings.allowFileAccess=true; web.settings.mediaPlaybackRequiresUserGesture=false
  web.webViewClient=WebViewClient(); web.addJavascriptInterface(Bridge(), "Android")
  setContentView(web); web.loadUrl("file:///android_asset/index.html")
  midiManager=getSystemService(MIDI_SERVICE) as? MidiManager
  midiManager?.registerDeviceCallback(object: MidiManager.DeviceCallback(){ override fun onDeviceAdded(info: MidiDeviceInfo){ connectMidi(info) }; override fun onDeviceRemoved(info: MidiDeviceInfo){ openDevices.remove(info.id)?.close() } }, Handler(Looper.getMainLooper()))
  midiManager?.devices?.forEach { connectMidi(it) }
 }
 private fun connectMidi(info: MidiDeviceInfo) { midiManager?.openDevice(info, { device -> if(device!=null){openDevices[info.id]=device; for(i in 0 until info.inputPortCount) { /* input ports receive app output */ }; for(i in 0 until info.outputPortCount){ device.openOutputPort(i)?.connect(object: MidiReceiver(){ override fun onSend(msg:ByteArray,offset:Int,count:Int,timestamp:Long){ val b=msg.copyOfRange(offset,offset+count); if(b.size>=3){ val status=b[0].toInt() and 255; val d1=b[1].toInt() and 127; val d2=b[2].toInt() and 127; runOnUiThread { js("onMidi($status,$d1,$d2)") } } } }) } } }, Handler(Looper.getMainLooper())) }
 private fun js(code:String){web.evaluateJavascript("window.$code;",null)}
 inner class Bridge {
  @JavascriptInterface fun importAudio(slot:String){runOnUiThread {pendingSlot=slot; val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply {addCategory(Intent.CATEGORY_OPENABLE);type="audio/*";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("audio/mpeg","audio/mp3","audio/wav","audio/x-wav","audio/wave","application/octet-stream"))};startActivityForResult(i,pickAudio)} }
  @JavascriptInterface fun listAudio():String { val dir=File(filesDir,"sounds");return dir.listFiles()?.joinToString(",") { "\"${it.name}\"" }?.let {"[$it]"} ?: "[]" }
  @JavascriptInterface fun getAudio(slot:String):String { if(!slot.matches(Regex("(note|drum)([0-9]|1[01])")))return ""; val f=File(File(filesDir,"sounds"),slot);return if(f.exists()) Base64.encodeToString(f.readBytes(),Base64.NO_WRAP) else "" }
 }
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==pickAudio&&resultCode==RESULT_OK){val uri:Uri=data?.data?:return;val slot=pendingSlot?:return; if(!slot.matches(Regex("(note|drum)([0-9]|1[01])")))return;executor.execute { try {val dir=File(filesDir,"sounds");dir.mkdirs();val target=File(dir,slot);contentResolver.openInputStream(uri)?.use {input -> target.outputStream().use {input.copyTo(it)} };runOnUiThread {js("audioImported('${slot}')")}}catch(e:Exception){runOnUiThread {js("showError('Falha ao importar áudio')")}} } } }
 override fun onDestroy(){openDevices.values.forEach{it.close()};executor.shutdown();super.onDestroy()}
}

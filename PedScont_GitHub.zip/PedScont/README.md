# Ped.Scont — aplicativo Android

Projeto Android (Kotlin + WebView) em orientação horizontal. Compilável no GitHub Actions.

## Como gerar o APK no GitHub
1. Crie um repositório vazio no GitHub.
2. Extraia o ZIP e envie **o conteúdo da pasta PedScont** para a raiz do repositório (incluindo `.github/workflows/android.yml`). Não envie o ZIP sem extrair.
3. Abra **Actions > Compilar APK > Run workflow** (ou faça um push para `main`).
4. Aguarde o build e abra **Artifacts > PedScont-APK** para baixar o APK de teste.
5. Instale o `app-debug.apk` no Android, permitindo instalação dessa origem.

## Operação
- **Toque curto** numa nota: inicia seu áudio em loop (substitui o loop anterior). Toque curto num drum pad: dispara uma vez.
- **Segure por 0,65 s** qualquer nota ou drum pad: seleciona MP3 ou WAV. O arquivo é copiado para armazenamento privado do app, preservado entre reinicializações (mas apagado ao desinstalar/limpar dados).
- **SALVAR**: informe o nome e escolha a playlist. Salva nota selecionada e BPM.
- **Playlist > Carregar**: inicia o loop da nota e o click no BPM gravado e volta à tela inicial.
- **Configurações > MIDI**: conecte controlador USB MIDI via OTG, escolha a ação, pressione Aprender MIDI e então o botão/tecla MIDI. Salva o mapa localmente.
- O click pode ficar mudo com a luz piscando. TAP TEMPO calcula o BPM. O filtro CUTOFF afeta apenas os loops das notas.
- Anotações são salvas automaticamente ao digitar, e podem ser salvas/renomeadas explicitamente.

## Observações
- O APK de Actions é de **depuração**, adequado para instalação pessoal e testes; não é um APK de publicação na Play Store.
- O motor de áudio usa Web Audio API dentro do WebView. Latência e precisão dependem do aparelho; não há sincronização profissional por sample-clock nem crossfade nesta primeira versão.
- O áudio importado é persistido no armazenamento interno privado. Não desinstale nem limpe os dados se quiser mantê-lo; faça backup dos originais.
- Suporte MIDI: mensagens Note On e Control Change de dispositivos expostos pela API Android MIDI (USB e outros reconhecidos pelo Android).
- O editor de notas é texto com suporte à entrada manuscrita via teclado do sistema; não implementa desenho livre em tinta digital nesta versão.
